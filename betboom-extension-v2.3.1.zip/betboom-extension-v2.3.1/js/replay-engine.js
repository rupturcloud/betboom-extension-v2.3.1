/**
 * Replay Engine
 * Replay completo de decisões sem re-execução (cinematic playback)
 * P2: Estabilização — permite auditar fluxos completos
 */

const ReplayEngine = (() => {
  const replayHistory = [];
  const snapshots = new Map();
  let isReplaying = false;
  let replaySpeed = 1;

  function registrarSnapshot(traceId, grafo, contexto, decisao) {
    snapshots.set(traceId, {
      traceId,
      timestamp: Date.now(),
      grafo: JSON.parse(JSON.stringify(grafo)),
      contexto: JSON.parse(JSON.stringify(contexto || {})),
      decisao: JSON.parse(JSON.stringify(decisao || {})),
      historico: Collector.getHistorico?.() || [],
      stats: DecisionEngine.getEstatisticas?.() || {}
    });

    if (snapshots.size > 100) {
      const oldest = Array.from(snapshots.keys())[0];
      snapshots.delete(oldest);
    }
  }

  function obterSnapshot(traceId) {
    return snapshots.get(traceId) || null;
  }

  function executarReplay(traceId, opcoes = {}) {
    const snapshot = obterSnapshot(traceId);
    if (!snapshot) {
      console.warn(`[REPLAY] Snapshot não encontrado: ${traceId}`);
      return null;
    }

    const replay = {
      traceId,
      snapshotTimestamp: snapshot.timestamp,
      grafo: snapshot.grafo,
      contexto: snapshot.contexto,
      decisao: snapshot.decisao,
      historico: snapshot.historico,
      stats: snapshot.stats,
      inicioReplay: Date.now(),
      fimReplay: null,
      durationMs: null,
      etapaAtual: 0,
      etapasTotal: snapshot.grafo.nodes.length,
      velocidade: opcoes.velocidade || 1,
      pausado: false,
      pausadoEm: null,
      resumoExecucao: null
    };

    replayHistory.push(replay);
    if (replayHistory.length > 50) replayHistory.shift();

    return replay;
  }

  function reproduzirReplayComAnimacao(traceId, containerEl, velocidade = 1) {
    if (isReplaying) return console.warn('[REPLAY] Replay já em andamento');
    isReplaying = true;
    replaySpeed = velocidade;

    const snapshot = obterSnapshot(traceId);
    if (!snapshot) {
      isReplaying = false;
      return;
    }

    if (!containerEl) {
      containerEl = document.createElement('div');
      containerEl.id = 'bb-replay-container';
      containerEl.style.cssText = `
        position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
        width: 90%; height: 90%; background: rgba(15,23,42,0.95);
        border: 2px solid #3b82f6; border-radius: 12px; z-index: 10000;
        overflow: auto; padding: 20px; color: #cbd5e1; font-family: Monaco;
      `;
      document.body.appendChild(containerEl);
    }

    containerEl.innerHTML = `
      <div style="display:flex; justify-content:space-between; margin-bottom:15px;">
        <h3 style="margin:0; color:#60a5fa;">🎬 Replay: ${traceId}</h3>
        <button id="bb-replay-close-btn" style="background:#334; color:#94a3b8; border:1px solid #555; padding:6px 12px; border-radius:4px; cursor:pointer;">Fechar</button>
      </div>
      <div id="bb-replay-controls" style="display:flex; gap:10px; margin-bottom:15px;">
        <button id="bb-replay-play-btn" style="background:#22c55e; color:#000; border:none; padding:6px 12px; border-radius:4px; cursor:pointer; font-weight:bold;">▶ Play</button>
        <button id="bb-replay-pause-btn" style="background:#f59e0b; color:#000; border:none; padding:6px 12px; border-radius:4px; cursor:pointer; font-weight:bold; display:none;">⏸ Pausar</button>
        <button id="bb-replay-stop-btn" style="background:#ef4444; color:#fff; border:none; padding:6px 12px; border-radius:4px; cursor:pointer; font-weight:bold;">⏹ Parar</button>
        <input id="bb-replay-speed" type="range" min="0.5" max="3" step="0.5" value="1" style="width:120px;">
        <label style="color:#94a3b8; font-size:12px;">Velocidade: <span id="bb-replay-speed-label">1x</span></label>
      </div>
      <div id="bb-replay-timeline" style="background:rgba(30,41,59,0.5); padding:10px; border-radius:4px; margin-bottom:15px; max-height:100px; overflow-y:auto;"></div>
      <div id="bb-replay-content" style="background:rgba(20,28,40,0.6); padding:15px; border-radius:4px; font-size:12px; line-height:1.5;"></div>
    `;

    const playBtn = document.getElementById('bb-replay-play-btn');
    const pauseBtn = document.getElementById('bb-replay-pause-btn');
    const stopBtn = document.getElementById('bb-replay-stop-btn');
    const closeBtn = document.getElementById('bb-replay-close-btn');
    const speedControl = document.getElementById('bb-replay-speed');
    const content = document.getElementById('bb-replay-content');
    const timeline = document.getElementById('bb-replay-timeline');

    speedControl.addEventListener('change', (e) => {
      replaySpeed = parseFloat(e.target.value);
      document.getElementById('bb-replay-speed-label').textContent = `${replaySpeed}x`;
    });

    let currentEtapa = 0;
    const nodes = snapshot.grafo.nodes;
    let replayPausado = false;

    function renderizarEtapa(idx) {
      const node = nodes[idx];
      if (!node) return;

      let html = `<strong style="color:#60a5fa;">Nó: ${node.nodeId}</strong><br>`;
      html += `Status: <span style="color:#${node.status === 'passed' ? '22c55e' : (node.status === 'failed' ? 'ef4444' : '94a3b8')}">${node.status}</span><br>`;
      html += `Latência: ${node.latencyMs}ms<br>`;
      html += `Confiança: ${node.confidence}%<br>`;
      html += `Convicção: ${node.conviction}%<br>`;
      html += `Consenso: ${node.consensus}%<br>`;
      if (node.reason) html += `Motivo: <span style="color:#f59e0b">${node.reason}</span><br>`;
      if (node.blockedBy.length > 0) html += `Bloqueado por: <span style="color:#ef4444">${node.blockedBy.join(', ')}</span><br>`;

      content.innerHTML = html;

      // Timeline visual
      let timelineHtml = '';
      nodes.forEach((n, i) => {
        const cor = i < idx ? '#22c55e' : (i === idx ? '#3b82f6' : '#475569');
        const emoji = i < idx ? '✓' : (i === idx ? '●' : '○');
        timelineHtml += `<span style="color:${cor}; margin-right:8px; cursor:pointer;" onclick="console.log('${i}')">${emoji} ${n.nodeId.substring(0, 6)}</span>`;
      });
      timeline.innerHTML = timelineHtml;
    }

    function avancarProxima() {
      if (currentEtapa < nodes.length - 1) {
        currentEtapa++;
        renderizarEtapa(currentEtapa);
      } else {
        playBtn.style.display = 'block';
        pauseBtn.style.display = 'none';
        isReplaying = false;
      }
    }

    playBtn.addEventListener('click', () => {
      playBtn.style.display = 'none';
      pauseBtn.style.display = 'block';
      replayPausado = false;

      const intervalo = Math.max(200 / replaySpeed, 50);
      const playInterval = setInterval(() => {
        if (!replayPausado && currentEtapa < nodes.length - 1) {
          avancarProxima();
        } else if (currentEtapa >= nodes.length - 1) {
          clearInterval(playInterval);
          playBtn.style.display = 'block';
          pauseBtn.style.display = 'none';
          isReplaying = false;
        }
      }, intervalo);

      pauseBtn.addEventListener('click', () => {
        replayPausado = true;
        playBtn.style.display = 'block';
        pauseBtn.style.display = 'none';
      }, { once: true });
    });

    stopBtn.addEventListener('click', () => {
      containerEl.remove();
      isReplaying = false;
      currentEtapa = 0;
    });

    closeBtn.addEventListener('click', () => {
      containerEl.remove();
      isReplaying = false;
    });

    renderizarEtapa(0);
  }

  function exportarReplayJSON(traceId) {
    const snapshot = obterSnapshot(traceId);
    if (!snapshot) return null;

    const exportData = {
      traceId,
      timestamp: snapshot.timestamp,
      grafo: snapshot.grafo,
      contexto: snapshot.contexto,
      decisao: snapshot.decisao,
      estatisticas: {
        nodosTotal: snapshot.grafo.nodes.length,
        nosPassed: snapshot.grafo.nodes.filter(n => n.status === 'passed').length,
        nosFailed: snapshot.grafo.nodes.filter(n => n.status === 'failed').length,
        nosBlocked: snapshot.grafo.nodes.filter(n => n.status === 'blocked').length,
        latenciaTotal: snapshot.grafo.nodes.reduce((sum, n) => sum + n.latencyMs, 0)
      }
    };

    return exportData;
  }

  function compararDoisReplays(traceId1, traceId2) {
    const snap1 = obterSnapshot(traceId1);
    const snap2 = obterSnapshot(traceId2);

    if (!snap1 || !snap2) return null;

    const diferencas = {
      ambosGrafos: {
        mesmaSequencia: JSON.stringify(snap1.grafo.nodes.map(n => n.nodeId)) === JSON.stringify(snap2.grafo.nodes.map(n => n.nodeId)),
        mesmoStatus: snap1.grafo.nodes.map(n => n.status).join() === snap2.grafo.nodes.map(n => n.status).join(),
        mesmaDecisao: snap1.decisao.cor === snap2.decisao.cor
      },
      diferenças: {
        nodsComStatusDiferente: snap1.grafo.nodes.filter((n1, i) => {
          const n2 = snap2.grafo.nodes[i];
          return n2 && n1.status !== n2.status;
        }).map(n => n.nodeId),
        latenciaMedia1: snap1.grafo.nodes.reduce((sum, n) => sum + n.latencyMs, 0) / snap1.grafo.nodes.length,
        latenciaMedia2: snap2.grafo.nodes.reduce((sum, n) => sum + n.latencyMs, 0) / snap2.grafo.nodes.length,
        decisaoMudou: snap1.decisao.cor !== snap2.decisao.cor
      }
    };

    return diferencas;
  }

  function getHistoricoReplays(limite = 20) {
    return replayHistory.slice(-limite);
  }

  return {
    registrarSnapshot,
    obterSnapshot,
    executarReplay,
    reproduzirReplayComAnimacao,
    exportarReplayJSON,
    compararDoisReplays,
    getHistoricoReplays,
    isReplaying: () => isReplaying,
    getSnapshotsCount: () => snapshots.size
  };
})();

window.ReplayEngine = ReplayEngine;
