/**
 * BetBoom Auto Pattern — Content Script (MVP WS Evo/Bac Bo) v2.1
 *
 * Top frame:
 * - inicializa overlay
 * - recebe eventos WS locais e relayed
 * - parseia Bac Bo (estado, resultado confirmado, saldo)
 *
 * Subframe:
 * - bridge-only
 * - injeta o interceptor e reencaminha eventos para o frame 0 via background
 */

(function () {
  'use strict';

  if (globalThis.__betboomContentMvpBooted) {
    console.info('[BetBoom Auto] Boot duplicado ignorado neste frame.');
    return;
  }
  globalThis.__betboomContentMvpBooted = true;

  const IS_TOP_FRAME = window.top === window;
  const FRAME_TAG = IS_TOP_FRAME ? 'top' : 'subframe';
  const WS_SOURCE = 'betboom-ws-interceptor';
  const WS_CHANNELS = new Set(['betboom-platform', 'evo-game', 'evo-chat', 'evo-video', 'other']);
  const WS_DIRECTIONS = new Set(['open', 'close', 'sent', 'received']);
  const ALLOWED_RESULTS = new Set(['Player', 'Banker', 'Tie']);
  const NON_BLOCKING_RUNTIME_ERRORS = [
    /receiving end does not exist/i,
    /message port closed/i,
    /frame with id 0 was removed/i,
    /tab was closed/i,
    /the page keeping the extension port is moved into back\/forward cache/i,
    /extension context invalidated/i
  ];

  let overlayInicializado = false;
  let wsCapturando = false;
  let wsDadosRecebidos = false;
  let modoPassivo = true;
  let iframeDetectado = false;
  let interceptorToken = null;
  let runtimeRelayInvalidado = false;
  let runtimeRelayWarned = false;

  const runtimeNoiseLogged = new Set();

  const parserState = {
    currentGameId: null,
    currentStage: null,
    pendingResolvedGameId: null,
    lastRoadSignature: null,
    lastSaldoReal: null,
    lastSaldoSource: null,
    lastStageKey: null,
    lastResultado: null,
    channelsAtivos: new Set(),
    totalMessages: 0,
    gameMessages: 0,
    totalConnections: 0,
    activeConnections: 0
  };

  Logger.info(`Content script v2.1 carregado [${FRAME_TAG}]`, window.location.href);
  console.log(`[BetBoom Auto] [${FRAME_TAG}] Content script carregado:`, window.location.href);

  function aguardarDOM() {
    return new Promise((resolve) => {
      if (document.readyState === 'complete' || document.readyState === 'interactive') {
        resolve();
        return;
      }
      document.addEventListener('DOMContentLoaded', resolve, { once: true });
    });
  }

  function carregarConfig() {
    return new Promise((resolve) => {
      try {
        const keys = [
          BBStrategyUtils.STORAGE_KEYS.config,
          BBStrategyUtils.STORAGE_KEYS.strategyLibrary,
          BBStrategyUtils.STORAGE_KEYS.strategyLibraryBootstrapped,
          BBStrategyUtils.STORAGE_KEYS.strategyPreferences
        ];

        chrome.storage.local.get(keys, (data) => {
          if (data?.config) {
            BBConfigUtils.applyPersistedConfig(CONFIG, data.config);
          }

          const bootstrap = BBStrategyUtils.ensureBootstrapPayload(data);
          CONFIG.strategyLibrary = bootstrap.strategyLibrary;
          CONFIG.strategyPreferences = bootstrap.strategyPreferences;

          if (bootstrap.shouldBootstrap) {
            chrome.storage.local.set({
              [BBStrategyUtils.STORAGE_KEYS.strategyLibrary]: bootstrap.strategyLibrary,
              [BBStrategyUtils.STORAGE_KEYS.strategyLibraryBootstrapped]: true,
              [BBStrategyUtils.STORAGE_KEYS.strategyPreferences]: bootstrap.strategyPreferences
            });
          }

          if (typeof PatternEngine !== 'undefined' && PatternEngine.setStrategyLibrary) {
            PatternEngine.setStrategyLibrary(bootstrap.strategyLibrary);
          }

          resolve();
        });
      } catch (error) {
        Logger.warn('Falha ao carregar config do storage:', error?.message || error);
        resolve();
      }
    });
  }

  function injetarWebSocketInterceptor() {
    if (globalThis.__betboomInterceptorRequested) {
      return;
    }
    globalThis.__betboomInterceptorRequested = true;
    interceptorToken = `bb-int-${Date.now()}-${Math.random().toString(16).slice(2, 10)}`;

    try {
      const script = document.createElement('script');
      script.src = chrome.runtime.getURL('js/injected.js');
      script.dataset.betboomInterceptor = FRAME_TAG;
      script.dataset.betboomInterceptorToken = interceptorToken;
      script.onload = function () {
        Logger.info(`Interceptor WS injetado [${FRAME_TAG}]`);
        this.remove();
      };
      script.onerror = function () {
        Logger.error(`Falha ao injetar interceptor WS [${FRAME_TAG}]`);
      };
      (document.head || document.documentElement).appendChild(script);
    } catch (error) {
      Logger.error(`Erro ao injetar interceptor [${FRAME_TAG}]`, error?.message || error);
    }
  }

  function toWindowEnvelope(event) {
    if (event.source !== window) return null;
    if (!event.data || event.data.source !== WS_SOURCE) return null;

    if (!interceptorToken || event.data.token !== interceptorToken) {
      return null;
    }

    const payload = event.data.payload || null;
    if (!isValidWindowEnvelope(payload)) {
      return null;
    }

    return payload;
  }

  function isValidWindowEnvelope(payload) {
    if (!payload || typeof payload !== 'object') return false;
    if (payload.kind !== 'bb_ws_raw') return false;
    if (!WS_CHANNELS.has(payload.channel || 'other')) return false;
    if (!WS_DIRECTIONS.has(payload.direction)) return false;
    if (typeof payload.socketUrl !== 'string') return false;
    if (payload.text !== null && typeof payload.text !== 'string') return false;
    if (payload.binaryLength !== null && !Number.isFinite(Number(payload.binaryLength))) return false;
    if (!Number.isFinite(Number(payload.timestamp))) return false;
    return true;
  }

  function safeQuerySelector(selector) {
    if (typeof selector !== 'string' || !selector.trim()) return null;

    try {
      return document.querySelector(selector);
    } catch (error) {
      Logger.warn('Seletor inválido ignorado:', selector, error?.message || error);
      return null;
    }
  }

  function hasElementForSelector(selector) {
    return Boolean(safeQuerySelector(selector));
  }

  function isNonBlockingRuntimeError(message) {
    if (!message) return false;
    return NON_BLOCKING_RUNTIME_ERRORS.some((pattern) => pattern.test(message));
  }

  function isRuntimeContextValid() {
    if (runtimeRelayInvalidado) return false;

    try {
      return typeof chrome !== 'undefined' &&
        !!chrome.runtime &&
        typeof chrome.runtime.sendMessage === 'function' &&
        typeof chrome.runtime.id === 'string' &&
        chrome.runtime.id.length > 0;
    } catch (_) {
      return false;
    }
  }

  function logRuntimeNoiseOnce(message) {
    const normalized = String(message || 'erro-runtime-desconhecido').trim().toLowerCase();
    if (runtimeNoiseLogged.has(normalized)) return;
    runtimeNoiseLogged.add(normalized);
    console.info('[BetBoom Auto] [service.worker] ruído não-bloqueante:', message);
  }

  function desativarRelaySubframe() {
    if (IS_TOP_FRAME) return;

    try {
      window.removeEventListener('message', tratarMensagemWindow);
    } catch (_) { }

    try {
      document.removeEventListener('click', tratarCliqueOperador, true);
    } catch (_) { }
  }

  function marcarRuntimeInvalidado(message, contexto = 'runtime') {
    runtimeRelayInvalidado = true;
    desativarRelaySubframe();

    if (runtimeRelayWarned) return;
    runtimeRelayWarned = true;

    const detail = message || 'Extension context invalidated';
    console.warn(`[BetBoom Auto] [${FRAME_TAG}] relay desativado (${contexto}): ${detail}`);
    Logger.warn(`Relay desativado [${FRAME_TAG}] (${contexto}): ${detail}`);
  }

  function readRuntimeLastErrorMessage() {
    try {
      return chrome.runtime?.lastError?.message || null;
    } catch (_) {
      return null;
    }
  }

  function safeRuntimeSendMessage(payload, contexto, onSuccess = null) {
    if (!isRuntimeContextValid()) {
      marcarRuntimeInvalidado('Extension context invalidated', contexto);
      return false;
    }

    try {
      chrome.runtime.sendMessage(payload, () => {
        const message = readRuntimeLastErrorMessage();
        if (message) {
          if (/extension context invalidated/i.test(message)) {
            marcarRuntimeInvalidado(message, contexto);
            return;
          }

          if (isNonBlockingRuntimeError(message)) {
            logRuntimeNoiseOnce(message);
            return;
          }

          Logger.warn(`Falha em ${contexto}:`, message);
          return;
        }

        if (typeof onSuccess === 'function') {
          onSuccess();
        }
      });

      return true;
    } catch (error) {
      const message = error?.message || String(error || 'Erro desconhecido');
      if (/extension context invalidated/i.test(message)) {
        marcarRuntimeInvalidado(message, contexto);
        return false;
      }

      Logger.warn(`Erro ao chamar runtime em ${contexto}:`, message);
      return false;
    }
  }

  function safeJsonParse(text) {
    if (typeof text !== 'string' || !text.trim()) return null;

    try {
      return JSON.parse(text);
    } catch (_) { }

    const trimmed = text.trim();
    const firstBrace = trimmed.indexOf('{');
    const lastBrace = trimmed.lastIndexOf('}');
    if (firstBrace >= 0 && lastBrace > firstBrace) {
      const maybeJson = trimmed.slice(firstBrace, lastBrace + 1);
      try {
        return JSON.parse(maybeJson);
      } catch (_) { }
    }

    const firstBracket = trimmed.indexOf('[');
    const lastBracket = trimmed.lastIndexOf(']');
    if (firstBracket >= 0 && lastBracket > firstBracket) {
      const maybeArray = trimmed.slice(firstBracket, lastBracket + 1);
      try {
        return JSON.parse(maybeArray);
      } catch (_) { }
    }

    return null;
  }

  function splitSelectors(selectors) {
    return String(selectors || '')
      .split(',')
      .map((selector) => selector.trim())
      .filter(Boolean);
  }

  function closestBySelectors(target, selectors) {
    if (!target || !selectors) return null;
    for (const selector of splitSelectors(selectors)) {
      try {
        const match = target.closest(selector);
        if (match) return match;
      } catch (_) { }
    }
    return null;
  }

  function inferirCorBotao(target) {
    if (!target) return null;
    if (closestBySelectors(target, CONFIG.selectors.btnVermelho)) return 'vermelho';
    if (closestBySelectors(target, CONFIG.selectors.btnAzul)) return 'azul';
    if (closestBySelectors(target, CONFIG.selectors.btnEmpate)) return 'empate';

    const attrs = [
      target.className || '',
      target.textContent || '',
      target.getAttribute?.('data-color') || ''
    ].join(' ').toLowerCase();

    if (/(red|vermelho|banker)/.test(attrs)) return 'vermelho';
    if (/(blue|azul|player|black|preto)/.test(attrs)) return 'azul';
    if (/(green|tie|empate|white)/.test(attrs)) return 'empate';
    return null;
  }

  function lerStakeAtualOperador() {
    let field = null;
    for (const selector of splitSelectors(CONFIG.selectors.inputStake)) {
      try {
        field = document.querySelector(selector);
      } catch (_) {
        field = null;
      }
      if (field) break;
    }
    if (!field) return Number(CONFIG.stakeInicial || 0);

    const numeric = Number(String(field.value || field.textContent || '').replace(',', '.').replace(/[^\d.]/g, ''));
    return Number.isFinite(numeric) && numeric > 0 ? numeric : Number(CONFIG.stakeInicial || 0);
  }

  function buildSessionReportResponse(limit = 200) {
    const reportJson = typeof exportSession === 'function' ? exportSession(limit) : '{}';
    const reportMarkdown = typeof exportSessionMarkdown === 'function' ? exportSessionMarkdown(limit) : '# Sessão\n\nSem dados.';
    const parsed = safeJsonParse(reportJson);
    const totalEntradas = Number(parsed?.resumoOperacional?.totalEntradas || parsed?.metadados?.totalEntradas || 0);
    const totalRounds = Number(parsed?.observabilidade?.session?.counters?.totalRodadasObservadas || 0);
    const totalRecommendations = Number((parsed?.observabilidade?.recommendations || []).length || 0);
    const timestampLabel = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    return {
      ok: true,
      hasData: totalEntradas > 0 || totalRounds > 0 || totalRecommendations > 0,
      filenameBase: `will-session-report-${timestampLabel}`,
      reportJson,
      reportMarkdown
    };
  }

  function mapearEstado(stage) {
    switch (stage) {
      case 'WaitingForBets':
        return 'apostando';
      case 'ClosingBets':
        return 'fechado';
      case 'AcceptingBets':
      case 'ButtonPressCheck':
      case 'FirstDie':
      case 'SecondDie':
      case 'ThirdDie':
      case 'FourthDie':
        return 'jogando';
      case 'Confirmation':
        return 'resultado';
      default:
        return stage ? String(stage) : 'aguardando';
    }
  }

  function normalizarTimer(nextStageIn) {
    if (typeof nextStageIn !== 'number' || Number.isNaN(nextStageIn)) return null;
    if (nextStageIn > 100) {
      return Math.max(0, Math.round(nextStageIn / 1000));
    }
    return Math.max(0, Math.round(nextStageIn));
  }

  function atualizarStatusWS() {
    CONFIG.canaisWSAtivos = Array.from(parserState.channelsAtivos);
    CONFIG.wsDadosRecebidos = wsDadosRecebidos === true;

    if (parserState.totalMessages % 50 === 0 && parserState.totalMessages > 0) {
      console.log(`[WS-HEALTH] Msgs: ${parserState.totalMessages} | Canais: ${CONFIG.canaisWSAtivos.join(', ')}`);
    }

    if (typeof ObservabilityEngine !== 'undefined' && ObservabilityEngine.atualizarTempoReal) {
      ObservabilityEngine.atualizarTempoReal({
        channels: CONFIG.canaisWSAtivos,
        totalMessages: parserState.totalMessages,
        wsDadosRecebidos,
        estadoRodada: CONFIG.estadoRodadaAtual || null
      });
    }

    if (!overlayInicializado || typeof Overlay === 'undefined') return;
    Overlay.atualizarStatusWS({
      totalConnections: parserState.totalConnections,
      activeConnections: parserState.activeConnections,
      totalMessages: parserState.totalMessages,
      gameMessages: parserState.gameMessages,
      channels: Array.from(parserState.channelsAtivos)
    });
  }

  function marcarCanalAtivo(channel, socketUrl) {
    if (!channel || channel === 'other') return;

    const sizeAntes = parserState.channelsAtivos.size;
    parserState.channelsAtivos.add(channel);
    if (parserState.channelsAtivos.size === sizeAntes) return;

    if (channel === 'evo-game') {
      iframeDetectado = true;
      modoPassivo = false;
      CONFIG.modoPassivo = false;
      if (overlayInicializado && typeof Overlay !== 'undefined') {
        Overlay.atualizarStatusIframe(true);
      }
    }

    console.log(`[BetBoom Auto] [ws] canal: ${channel}`, socketUrl || '');
    if (overlayInicializado && typeof Overlay !== 'undefined' && Overlay.addLog) {
      Overlay.addLog(`Canal WS ativo: ${channel}`, 'info');
    }

    atualizarStatusWS();
  }

  function aplicarSaldoOficial(valor, source) {
    const saldo = Number(valor);
    if (!Number.isFinite(saldo) || saldo < 0) return;

    const mudouValor = parserState.lastSaldoReal !== saldo;
    const mudouFonte = parserState.lastSaldoSource !== source;

    parserState.lastSaldoReal = saldo;
    parserState.lastSaldoSource = source;
    CONFIG.saldoReal = saldo;
    CONFIG.fonteDoSaldo = source;
    wsDadosRecebidos = true;
    CONFIG.wsDadosRecebidos = true;
    if (source === 'evo-game' || iframeDetectado) {
      modoPassivo = false;
      CONFIG.modoPassivo = false;
    }

    if (overlayInicializado && typeof Overlay !== 'undefined') {
      Overlay.atualizarSaldoReal(saldo);
      Overlay.atualizarStatusIframe(Boolean(iframeDetectado));
    }

    if (mudouValor || mudouFonte) {
      console.log(`[BetBoom Auto] [saldo] ${source}: ${saldo.toFixed(2)}`);
      if (overlayInicializado && typeof Overlay !== 'undefined' && Overlay.addLog) {
        Overlay.addLog(`Saldo real (${source}): R$ ${saldo.toFixed(2)}`, 'success');
      }
    }

    if (typeof ObservabilityEngine !== 'undefined' && ObservabilityEngine.atualizarSaldo) {
      ObservabilityEngine.atualizarSaldo(saldo, { source });
    }
  }

  function atualizarEstadoRodada(game) {
    if (!game) return;

    parserState.currentGameId = game.id || parserState.currentGameId;
    parserState.currentStage = game.stage || parserState.currentStage;
    CONFIG.estadoRodadaAtual = mapearEstado(game.stage);
    CONFIG.roundIdAtual = game.id || parserState.currentGameId || null;
    CONFIG.wsDadosRecebidos = true;
    CONFIG.canaisWSAtivos = Array.from(parserState.channelsAtivos);

    if (game.stage === 'Confirmation' && game.id) {
      parserState.pendingResolvedGameId = game.id;
    }

    const estadoMapeado = mapearEstado(game.stage);
    const timer = normalizarTimer(game.nextStageIn);
    const stageKey = `${game.id || 'sem-game'}:${game.stage || 'sem-stage'}`;

    wsDadosRecebidos = true;
    modoPassivo = false;
    CONFIG.modoPassivo = false;

    if (parserState.lastStageKey !== stageKey) {
      parserState.lastStageKey = stageKey;
      console.log(`[BetBoom Auto] [parser] estado: ${estadoMapeado} (${game.stage || 'desconhecido'})`);
      if (overlayInicializado && typeof Overlay !== 'undefined' && Overlay.addLog) {
        Overlay.addLog(`Estado da rodada: ${estadoMapeado}`, 'info');
      }
    }

    if (overlayInicializado && typeof Overlay !== 'undefined') {
      Overlay.atualizarEstadoRodada({
        estado: estadoMapeado,
        raw: game.stage || null,
        timer
      });
      Overlay.atualizarStatusIframe(true);
    }

    if (typeof ObservabilityEngine !== 'undefined' && ObservabilityEngine.atualizarTempoReal) {
      ObservabilityEngine.atualizarTempoReal({
        channels: Array.from(parserState.channelsAtivos),
        totalMessages: parserState.totalMessages,
        wsDadosRecebidos,
        estadoRodada: CONFIG.estadoRodadaAtual || null
      });
    }
  }

  function winnerParaCor(winner) {
    if (winner === 'Player') return 'azul';
    if (winner === 'Banker') return 'vermelho';
    if (winner === 'Tie') return 'empate';
    return null;
  }

  function processarResultadoConfirmado(history) {
    if (!Array.isArray(history) || history.length === 0) return;

    const ultimo = history[history.length - 1];
    if (!ultimo || !ALLOWED_RESULTS.has(ultimo.winner)) return;

    const signature = `${history.length}:${ultimo.winner}:${ultimo.playerScore}:${ultimo.bankerScore}`;
    if (parserState.lastRoadSignature === signature) return;
    parserState.lastRoadSignature = signature;

    const resultado = {
      cor: winnerParaCor(ultimo.winner),
      vencedor: ultimo.winner,
      playerScore: Number(ultimo.playerScore),
      bankerScore: Number(ultimo.bankerScore),
      gameId: parserState.pendingResolvedGameId || parserState.currentGameId || null,
      confirmedBy: 'bacbo.road',
      signature,
      timestamp: Date.now()
    };

    parserState.lastResultado = resultado;
    parserState.pendingResolvedGameId = null;
    CONFIG.ultimoResultadoConfirmado = resultado;
    wsDadosRecebidos = true;
    modoPassivo = false;
    CONFIG.modoPassivo = false;

    console.log(`[BetBoom Auto] [resultado] confirmado: ${resultado.vencedor} ${resultado.playerScore}x${resultado.bankerScore}`);

    if (typeof Collector !== 'undefined') {
      Collector.adicionarResultadoConfirmado(resultado);
    }

    if (overlayInicializado && typeof Overlay !== 'undefined') {
      Overlay.atualizarUltimoResultado(resultado);
      Overlay.atualizarUI();
      if (Overlay.addLog) {
        Overlay.addLog(`Rodada ${Collector.getRodadaAtual()}: Resultado ${resultado.vencedor} ${resultado.playerScore}x${resultado.bankerScore}`, 'success');
        Overlay.addLog(`Resultado real: ${resultado.vencedor} ${resultado.playerScore}x${resultado.bankerScore}`, 'success');
      }
    }
  }

  function processarPayloadJogo(payload) {
    if (!payload || typeof payload !== 'object') return;

    if (payload.type === 'balanceUpdated') {
      const saldo = payload?.args?.balance;
      if (typeof saldo === 'number') {
        aplicarSaldoOficial(saldo, 'evo-game');
      }
      return;
    }

    if (payload.type === 'bacbo.playerState') {
      const game = payload?.args?.game;
      if (game) {
        atualizarEstadoRodada(game);

        // --- EXTRAÇÃO DOS DADOS (PULMÃO/VISÃO) ---
        if (game.dice) {
          const p1 = game.dice.player?.[0] || 0;
          const p2 = game.dice.player?.[1] || 0;
          const b1 = game.dice.banker?.[0] || 0;
          const b2 = game.dice.banker?.[1] || 0;

          if (p1 || p2 || b1 || b2) {
            const pSum = p1 + p2;
            const bSum = b1 + b2;
            const winner = pSum > bSum ? 'PLAYER' : (bSum > pSum ? 'BANKER' : 'EMPATE');

            console.log(`%c[DADOS] P(${p1}+${p2}=${pSum}) vs B(${b1}+${b2}=${bSum}) | Vencedor: ${winner}`, 'color:cyan;font-weight:bold');
            if (overlayInicializado && typeof Overlay !== 'undefined' && Overlay.addLog) {
              Overlay.addLog(`Resultado: ${winner} (${pSum}x${bSum})`, 'success');
            }
          }
        }
      }
      return;
    }

    if (payload.type === 'bacbo.road') {
      processarResultadoConfirmado(payload?.args?.history);
    }
  }

  function processarPayloadPlataforma(payload) {
    if (!payload || typeof payload !== 'object') return;

    if (payload.namespace === 'accountBalance' && payload.method === 'getMy') {
      const balances = payload?.result?.balances;
      if (!Array.isArray(balances)) return;

      const oficial = balances.find((item) => item && item.real === true && item.display === true);
      if (oficial && typeof oficial.value === 'number') {
        aplicarSaldoOficial(oficial.value, 'betboom-platform');
      }
    }
  }

  function processarEnvelopeWS(envelope) {
    if (!envelope || envelope.kind !== 'bb_ws_raw') return;

    wsCapturando = true;

    if (envelope.direction === 'open') {
      parserState.totalConnections += 1;
      parserState.activeConnections += 1;
      marcarCanalAtivo(envelope.channel, envelope.socketUrl);
      atualizarStatusWS();
      return;
    }

    if (envelope.direction === 'close') {
      parserState.activeConnections = Math.max(0, parserState.activeConnections - 1);
      atualizarStatusWS();
      return;
    }

    if (envelope.direction !== 'received') return;

    parserState.totalMessages += 1;
    if (envelope.channel === 'evo-game') {
      parserState.gameMessages += 1;
    }

    marcarCanalAtivo(envelope.channel, envelope.socketUrl);
    atualizarStatusWS();

    if (!envelope.text) return;

    const payload = safeJsonParse(envelope.text);
    if (!payload) return;

    if (envelope.channel === 'evo-game') {
      processarPayloadJogo(payload);
      return;
    }

    if (envelope.channel === 'betboom-platform') {
      processarPayloadPlataforma(payload);
    }
  }

  function registrarEntradaManualOperador(payload) {
    if (!IS_TOP_FRAME || !payload?.cor || typeof DecisionEngine === 'undefined') return;
    if (CONFIG.estadoRodadaAtual !== 'apostando') return;

    const state = DecisionEngine.getState?.() || {};
    if (!state.isAtivo || state.isPausado) return;

    const roundId = CONFIG.roundIdAtual || payload.roundId || null;
    if (!roundId) return;
    if (DecisionEngine.hasEntradaExecutadaParaRound?.(roundId)) return;

    const ultimaDecisao = DecisionEngine.getEstatisticas?.()?.ultimaDecisao || null;
    const entry = DecisionEngine.registrarEntradaManual({
      roundId,
      rodada: Collector.getRodadaAtual() + 1,
      estrategia: ultimaDecisao?.nome || 'Entrada manual do operador',
      strategyId: ultimaDecisao?.strategyId || null,
      origem: ultimaDecisao?.source || 'user',
      sequenciaReconhecida: ultimaDecisao?.recognizedSequence || null,
      entradaSugerida: ultimaDecisao?.cor || payload.cor,
      entradaExecutada: payload.cor,
      gale: Number.isFinite(Number(ultimaDecisao?.maxGalesPermitido)) ? Number(ultimaDecisao.maxGalesPermitido) : Number(CONFIG.maxGales || 0),
      protecaoEmpate: Boolean(ultimaDecisao?.usarProtecaoEmpate ?? CONFIG.protegerEmpate),
      valorProtecao: Boolean(ultimaDecisao?.usarProtecaoEmpate ?? CONFIG.protegerEmpate) ? Number(CONFIG.valorProtecaoEmpate || 0) : 0,
      stake: Number.isFinite(Number(payload.stake)) ? Number(payload.stake) : Number(CONFIG.stakeInicial || 0),
      timestampEntrada: payload.timestampEntrada || Date.now(),
      statusExecucao: 'manual-registrada',
      targetVisualTexto: payload.targetText || null,
      targetSelector: payload.targetSelector || null
    });

    if (!entry) return;

    if (overlayInicializado && typeof Overlay !== 'undefined' && Overlay.registrarEntradaManual) {
      Overlay.registrarEntradaManual(entry);
      Overlay.atualizarUI();
    } else if (typeof BBTelemetry !== 'undefined' && BBTelemetry.push) {
      BBTelemetry.push({
        timestamp: entry.timestampEntrada || Date.now(),
        roundId: entry.roundId || null,
        history: Collector.getCoresRecentes(12),
        estrategiaDetectada: entry.estrategia || null,
        origem: entry.origem || null,
        sequenciaReconhecida: entry.sequenciaReconhecida || null,
        entradaSugerida: entry.entradaSugerida || null,
        entradaExecutada: entry.entradaExecutada || null,
        tipoEntrada: 'manual',
        gale: Number(entry.gale || 0),
        protecaoEmpate: entry.protecaoEmpate === true,
        estadoRodada: CONFIG.estadoRodadaAtual || null,
        saldo: Number.isFinite(Number(CONFIG.saldoReal)) ? Number(CONFIG.saldoReal) : null,
        stake: Number(entry.stake || 0),
        alvoAposta: BBStrategyUtils.getEntryLabel(entry.entradaExecutada || ''),
        statusExecucao: 'manual-registrada'
      });
    }

    if (typeof ObservabilityEngine !== 'undefined' && ObservabilityEngine.registrarEntrada) {
      ObservabilityEngine.registrarEntrada(entry, {
        history: Collector.getCoresRecentes(12),
        rodadaNumero: Collector.getRodadaAtual() + 1
      });
    }
  }

  function tratarCliqueOperador(event) {
    if (!event?.isTrusted) return;
    const target = event.target;
    if (!target || target.closest?.('#bb-auto-overlay')) return;

    const cor = inferirCorBotao(target);
    if (!cor) return;

    const payload = {
      kind: 'bb_operator_entry',
      cor,
      stake: lerStakeAtualOperador(),
      timestampEntrada: Date.now(),
      targetText: String(target.textContent || '').trim().slice(0, 80),
      targetSelector: target?.tagName ? target.tagName.toLowerCase() : null
    };

    if (IS_TOP_FRAME) {
      registrarEntradaManualOperador(payload);
      return;
    }

    if (runtimeRelayInvalidado) return;

    safeRuntimeSendMessage({
      type: 'BB_RELAY_OPERATOR_EVENT',
      event: payload
    }, 'relay clique manual do subframe');
  }

  // Seletores candidatos para cada alvo de aposta
  const CLICK_CANDIDATES = {
    player: [
      '[data-betia-id="bet-player"]',
      '[data-automation-id="betting-grid-item-player"]',
      '[data-role="player-bet-spot"]',
      '[class*="betspot--player"]',
      '[class*="wc-bet-spot--player"]'
    ],
    banker: [
      '[data-betia-id="bet-banker"]',
      '[data-automation-id="betting-grid-item-banker"]',
      '[data-role="banker-bet-spot"]',
      '[class*="betspot--banker"]',
      '[class*="wc-bet-spot--banker"]'
    ],
    tie: [
      '[data-betia-id="bet-tie"]',
      '[data-automation-id="betting-grid-item-tie"]',
      '[data-role="tie-bet-spot"]',
      '[class*="betspot--tie"]',
      '[class*="wc-bet-spot--tie"]'
    ],
    chip: [
      '[data-betia-id^="chip-"]',
      '[data-automation-id^="chip-"]',
      '[class*="chip"]:not([class*="container"])',
      '[data-role*="chip"]',
      'button[class*="chip"]',
      'div[class*="chip"]',
      '[data-testid*="chip"]',
      '[aria-label*="chip"]',
      '.chip',
      '.Chip',
      '[class*="Chip"]',
      '[class*="betting-chip"]',
      '[class*="wc-chip"]',
      'button[data-value]',
      'div[data-chip-value]'
    ],
    confirm: [
      '[data-betia-id="bet-confirm"]',
      '[data-automation-id="bet-button-confirm"]',
      '[class*="button--confirm"]',
      '[class*="wc-confirm-button"]',
      '[data-role="confirm-button"]',
      'button.confirm-bet-button',
      '.confirm-button button'
    ]
  };

  function encontrarElemento(lista) {
    for (const sel of lista) {
      try {
        const el = document.querySelector(sel);
        if (el && el.getBoundingClientRect().width > 0) return { el, sel };
      } catch (_) { }
    }
    return null;
  }

  function encontrarElementoFallback(tipo = 'chip') {
    if (tipo !== 'chip') return null;

    const allButtons = Array.from(document.querySelectorAll('button, div[role="button"], [onclick]'));

    for (const el of allButtons) {
      const rect = el.getBoundingClientRect();
      const style = window.getComputedStyle(el);
      const text = (el.textContent || '').trim();

      if (rect.width === 0 || rect.height === 0) continue;
      if (style.display === 'none' || style.visibility === 'hidden') continue;

      const isLikelyChip = (
        (rect.width >= 30 && rect.width <= 150 && rect.height >= 30 && rect.height <= 150) ||
        /\d+/.test(text) ||
        el.className.includes('chip') ||
        el.className.includes('bet') ||
        el.id?.includes('chip') ||
        el.getAttribute('data-value')
      );

      if (isLikelyChip) {
        return { el, sel: `[fallback-chip: ${text || 'sem-label'}]` };
      }
    }

    return null;
  }

  function executarCliqueReal(el) {
    if (!el) return false;
    try {
      el.scrollIntoView({ block: 'center', behavior: 'smooth' });
      const rect = el.getBoundingClientRect();
      const x = rect.left + rect.width / 2;
      const y = rect.top + rect.height / 2;

      // Diagnóstico de visibilidade
      const style = window.getComputedStyle(el);
      const isVisible = rect.width > 0 && rect.height > 0 && style.display !== 'none' && style.visibility !== 'hidden';
      
      console.log(`[BB-CLICK] [target] ${el.tagName}#${el.id}.${el.className.split(' ').join('.')} | visible=${isVisible} | pos=${x.toFixed(0)},${y.toFixed(0)}`);

      if (!isVisible) {
        console.warn('[BB-CLICK] Alvo invisível, clique pode falhar.');
      }

      const pointerOpts = { bubbles: true, cancelable: true, clientX: x, clientY: y, pointerId: 1, isPrimary: true };
      const mouseOpts = { bubbles: true, cancelable: true, clientX: x, clientY: y };

      const dispatch = (type) => {
        let ev;
        if (type.startsWith('pointer') && typeof window.PointerEvent !== 'undefined') {
          ev = new PointerEvent(type, pointerOpts);
        } else {
          ev = new MouseEvent(type, mouseOpts);
        }
        return el.dispatchEvent(ev);
      };

      // Sequência completa de interação
      const sequence = [
        'pointerover', 'mouseover', 
        'pointerdown', 'mousedown', 
        'pointerup', 'mouseup', 
        'click'
      ];

      sequence.forEach(dispatch);

      // Clique nativo como fallback final
      el.click();
      
      return { ok: true, x, y };
    } catch (e) {
      console.warn('[BB-CLICK] Erro ao executar clique:', e);
      return { ok: false };
    }
  }

  async function executarComandoClique(alvo, chipValue = null) {
    console.log(`[BB-CLICK] Iniciando comando: alvo=${alvo}, valor solicitado=${chipValue}`);

    // 1. Encontrar e clicar na ficha (usa ChipDetector robusto)
    let chip = null;
    const targets = ['player', 'banker', 'tie'];
    const normalizedAlvo = targets.includes(String(alvo).toLowerCase()) ? String(alvo).toLowerCase() : 'player';

    if (chipValue && typeof ChipDetector !== 'undefined') {
      // Usar novo detector com retry
      chip = await ChipDetector.encontrarComRetry(chipValue, 4, 150);
      if (chip) {
        console.log(`[BB-CLICK] ✅ Ficha encontrada via ChipDetector: ${chip.sel}`);
      }
    }

    // Fallback para versão antiga se ChipDetector não está disponível
    if (!chip && chipValue) {
      const valStr = String(chipValue).replace(/[^\d]/g, '');
      const evoSpecificSelectors = [
        `[data-betia-id="chip-${valStr}"]`,
        `[data-automation-id="chip-${valStr}"]`,
        `[data-value="${valStr}"]`
      ];

      for (const sel of evoSpecificSelectors) {
        const el = document.querySelector(sel);
        if (el && el.getBoundingClientRect().width > 0) {
          chip = { el, sel };
          console.log(`[BB-CLICK] Ficha encontrada (fallback legacy): ${sel}`);
          break;
        }
      }
    }

    // Último fallback: visual
    if (!chip) {
      if (typeof ChipDetector !== 'undefined') {
        chip = ChipDetector.encontrarFallback();
      } else {
        chip = encontrarElementoFallback('chip');
      }
      if (chip) console.log(`[BB-CLICK] Usando fallback visual: ${chip.sel}`);
    }

    let chipSel = null;
    let chipValorEncontrado = null;
    if (chip) {
      chipValorEncontrado = chip.el.textContent?.trim() || chip.el.getAttribute('data-value') || '?';
      chipSel = chip.sel;
      executarCliqueReal(chip.el);
      console.log(`[BB-CLICK] ✅ Ficha clicada: ${chipValorEncontrado}`);
    } else {
      console.warn('[BB-CLICK] ❌ Nenhuma ficha encontrada para clicar! Diagnóstico:');
      if (typeof ChipDetector !== 'undefined') {
        ChipDetector.diagnosticar();
      }
    }

    // 2. Delay maior e clicar no spot (Evolution às vezes é lenta para registrar a ficha)
    setTimeout(() => {
      const candidatos = CLICK_CANDIDATES[normalizedAlvo] || CLICK_CANDIDATES.player;
      const found = encontrarElemento(candidatos);

      const resultado = {
        source: 'bb-click-result',
        alvo: normalizedAlvo,
        ok: false,
        seletor: null,
        texto: null,
        chipSel,
        chipValor: chipValorEncontrado,
        ts: Date.now()
      };

      if (found) {
        const clique = executarCliqueReal(found.el);
        resultado.ok = clique.ok;
        resultado.x = clique.x;
        resultado.y = clique.y;
        resultado.seletor = found.sel;
        resultado.texto = found.el.textContent?.trim()?.slice(0, 40) || null;

        // 3. Clique automático de confirmação (se disponível)
        if (resultado.ok) {
          setTimeout(() => {
            const confirmBtn = encontrarElemento(CLICK_CANDIDATES.confirm);
            if (confirmBtn) {
              const confirmClique = executarCliqueReal(confirmBtn.el);
              // Também enviamos coordenadas da confirmação para o hardware click
              window.top.postMessage({ ...resultado, source: 'bb-click-result-hardware', x: confirmClique.x, y: confirmClique.y, isConfirm: true }, '*');
              console.log(`[BB-CLICK] ✅ Confirmação clicada: ${confirmBtn.sel}`);
            } else {
              console.warn('[BB-CLICK] ⚠️ Botão de confirmação não encontrado após clique principal.');
            }
          }, 450); // Aumentado para 450ms
        }
      }

      // Responder para o frame pai
      window.top.postMessage(resultado, '*');
      console.log(`%c[BB-CLICK] ${resultado.ok ? '✅' : '❌'} ${normalizedAlvo} | seletor: ${resultado.seletor || 'NÃO ENCONTRADO'}`, 'color:cyan;font-weight:bold');
    }, 100); // Delay inicial para garantir que o frame processou o sinal
  }

  async function tratarMensagemWindow(event) {
    // Comando de clique vindo do frame pai → executar no iframe
    if (!IS_TOP_FRAME && event.data?.source === 'bb-click-cmd') {
      await executarComandoClique(event.data.alvo || 'player', event.data.valor || null);
      return;
    }

    // Resultado de clique vindo do iframe → repassar para o overlay E disparar hardware click
    if (IS_TOP_FRAME && (event.data?.source === 'bb-click-result' || event.data?.source === 'bb-click-result-hardware')) {
      const r = event.data;
      
      // 1. Log no Overlay
      if (r.source === 'bb-click-result') {
        const label = r.alvo === 'player' ? 'AZUL (Jogador)' : (r.alvo === 'banker' ? 'VERMELHO (Banca)' : 'EMPATE');
        const msg = r.ok
          ? `✅ Operando: ${label} | ${r.seletor}`
          : `❌ Falhou em ${label} — não encontrado`;
        if (overlayInicializado && typeof Overlay !== 'undefined' && Overlay.addLog) {
          Overlay.addLog(msg, r.ok ? 'success' : 'error');
        }
      }

      // 2. DISPARO DE HARDWARE SOBERANO (Chrome Debugger API)
      if (r.ok && typeof r.x === 'number' && typeof r.y === 'number') {
        // Lógica de Geometria Recursiva: Somar offsets de todos os pais até o topo
        enviarCoordenadaSoberana(r, event.source);
      }
      return;
    }

    /**
     * Envia a coordenada para o topo de forma recursiva.
     * Se estiver num iframe, manda o offset local + r.x/y para o pai.
     * O pai somará o próprio offset e mandará para o avô, até chegar no Top Frame.
     */
    function enviarCoordenadaSoberana(r, sourceWindow) {
      if (IS_TOP_FRAME) {
        // Já estamos no topo! Descobrir qual iframe enviou para pegar o offset
        const iframes = Array.from(document.querySelectorAll('iframe'));
        const sourceFrame = iframes.find(f => f.contentWindow === sourceWindow);
        
        if (sourceFrame) {
          const frameRect = sourceFrame.getBoundingClientRect();
          const globalX = frameRect.left + r.x;
          const globalY = frameRect.top + r.y;

          chrome.runtime.sendMessage({
            type: 'BB_EXECUTE_HARDWARE_CLICK',
            x: globalX,
            y: globalY
          }, (response) => {
            if (response?.ok) {
              console.log(`%c[BB-HARDWARE] ✅ Clique SOBERANO executado: ${globalX.toFixed(0)},${globalY.toFixed(0)}`, 'color:#00ff00; font-weight:bold;');
              if (overlayInicializado && typeof Overlay !== 'undefined' && Overlay.setHardwareStatus) {
                Overlay.setHardwareStatus(true);
              }
            } else {
              console.warn('[BB-HARDWARE] ❌ Falha no clique de hardware:', response?.error);
            }
          });
        }
      } else {
        // No subframe: passamos o resultado para cima (window.parent)
        // O pai vai receber isso no 'tratarMensagemWindow' e vai cair no CASE do IS_TOP_FRAME (ou repassar)
        window.parent.postMessage({
          ...r,
          source: 'bb-click-result-hardware'
        }, '*');
      }
    }

    const envelope = toWindowEnvelope(event);
    if (!envelope) return;

    if (IS_TOP_FRAME) {
      processarEnvelopeWS(envelope);
      return;
    }

    if (runtimeRelayInvalidado) return;

    safeRuntimeSendMessage({
      type: 'BB_RELAY_WS_EVENT',
      envelope
    }, 'relay evento WS do subframe');
  }

  function registrarListenersRuntime() {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg?.type === 'BB_TOP_FRAME_WS_EVENT' && IS_TOP_FRAME) {
        processarEnvelopeWS(msg.envelope);
        sendResponse?.({ ok: true });
        return false;
      }

      if (msg?.type === 'BB_TOP_FRAME_OPERATOR_EVENT' && IS_TOP_FRAME) {
        registrarEntradaManualOperador(msg.event);
        sendResponse?.({ ok: true });
        return false;
      }

      if (!IS_TOP_FRAME) {
        return false;
      }

      switch (msg?.type) {
        case 'GET_STATUS':
          sendResponse({
            decision: typeof DecisionEngine !== 'undefined' ? DecisionEngine.getEstatisticas() : null,
            collector: typeof Collector !== 'undefined' ? Collector.getEstatisticas() : null,
            strategyStatus: typeof PatternEngine !== 'undefined' && PatternEngine.getStrategyStatus
              ? PatternEngine.getStrategyStatus()
              : null,
            config: CONFIG,
            iframeDetectado,
            modoPassivo,
            wsCapturando,
            wsDadosRecebidos,
            saldoReal: CONFIG.saldoReal || null,
            fonteDoSaldo: CONFIG.fonteDoSaldo || 'nenhuma',
            channels: Array.from(parserState.channelsAtivos),
            observability: typeof ObservabilityEngine !== 'undefined' && ObservabilityEngine.getSnapshot
              ? ObservabilityEngine.getSnapshot()
              : null
          });
          return true;

        case 'UPDATE_CONFIG': {
          const configAtualizada = BBConfigUtils.mergePersistedConfig(msg.config || {});
          BBConfigUtils.applyPersistedConfig(CONFIG, configAtualizada);
          chrome.storage.local.set({ config: configAtualizada });
          if (overlayInicializado && typeof Overlay !== 'undefined' && Overlay.aplicarModoDebug) {
            Overlay.aplicarModoDebug();
          }
          if (overlayInicializado && typeof Overlay !== 'undefined' && Overlay.addLog) {
            Overlay.addLog('Configurações atualizadas', 'info');
          }
          sendResponse({ ok: true });
          return true;
        }

        case 'UPDATE_STRATEGIES':
          CONFIG.strategyLibrary = BBStrategyUtils.ensureStrategyLibrary(msg.strategies || []);
          CONFIG.strategyPreferences = {
            ...(CONFIG.strategyPreferences || {}),
            ...(msg.preferences || {})
          };

          if (typeof PatternEngine !== 'undefined' && PatternEngine.setStrategyLibrary) {
            PatternEngine.setStrategyLibrary(CONFIG.strategyLibrary);
          }

          if (overlayInicializado && typeof Overlay !== 'undefined' && Overlay.addLog) {
            Overlay.addLog(`Estratégias atualizadas: ${CONFIG.strategyLibrary.filter(s => s.active).length} ativa(s)`, 'info');
          }

          sendResponse({ ok: true });
          return true;

        case 'START':
          document.getElementById('bb-btn-start')?.click();
          sendResponse({ ok: true });
          return true;

        case 'PAUSE':
          document.getElementById('bb-btn-pause')?.click();
          sendResponse({ ok: true });
          return true;

        case 'STOP':
          document.getElementById('bb-btn-stop')?.click();
          sendResponse({ ok: true });
          return true;

        case 'TEST_DETECTION':
          const strategyStatus = typeof PatternEngine !== 'undefined' && PatternEngine.getStrategyStatus
            ? PatternEngine.getStrategyStatus()
            : null;
          sendResponse({
            historicoContainer: Boolean(typeof Collector !== 'undefined' && Collector.isContainerEncontrado && Collector.isContainerEncontrado()),
            btnVermelho: hasElementForSelector(CONFIG.selectors.btnVermelho),
            btnAzul: hasElementForSelector(CONFIG.selectors.btnAzul),
            btnEmpate: hasElementForSelector(CONFIG.selectors.btnEmpate),
            inputStake: hasElementForSelector(CONFIG.selectors.inputStake),
            timer: hasElementForSelector(CONFIG.selectors.timer),
            pronto: parserState.channelsAtivos.has('evo-game'),
            strategiesAtivas: strategyStatus?.ativas || 0,
            iframeDetectado,
            modoPassivo,
            wsCapturando,
            wsDadosRecebidos,
            saldoReal: CONFIG.saldoReal || null
          });
          return true;

        case 'SHOW_OVERLAY':
          Overlay.mostrar();
          sendResponse({ ok: true });
          return true;

        case 'HIDE_OVERLAY':
          Overlay.esconder();
          sendResponse({ ok: true });
          return true;

        case 'EXPORT_SESSION_REPORT':
          sendResponse(buildSessionReportResponse(msg.limit || 200));
          return true;

        default:
          return false;
      }
    });
  }

  function sincronizarOverlayInicial() {
    if (!overlayInicializado || typeof Overlay === 'undefined') return;

    Overlay.atualizarStatusIframe(iframeDetectado);
    atualizarStatusWS();

    if (parserState.lastSaldoReal !== null) {
      Overlay.atualizarSaldoReal(parserState.lastSaldoReal);
    }

    if (parserState.lastResultado) {
      Overlay.atualizarUltimoResultado(parserState.lastResultado);
    }

    if (parserState.currentStage) {
      Overlay.atualizarEstadoRodada({
        estado: mapearEstado(parserState.currentStage),
        raw: parserState.currentStage,
        timer: null
      });
    }
  }

  async function inicializarTopFrame() {
    Logger.info('Iniciando inicialização do Top Frame...');

    // 1. Aguardar DOM com limite de tempo
    try {
      await Promise.race([
        aguardarDOM(),
        new Promise(resolve => setTimeout(resolve, 3000)) // Timeout de 3s para o DOM
      ]);
    } catch (e) {
      Logger.warn('Aviso: aguardarDOM demorou demais ou falhou. Prosseguindo...');
    }

    // 2. Carregar Configurações e Observabilidade com resiliência
    const initProcess = async () => {
      try {
        await carregarConfig();
        if (typeof ObservabilityEngine !== 'undefined' && ObservabilityEngine.bootstrap) {
          await ObservabilityEngine.bootstrap();
          ObservabilityEngine.atualizarTempoReal({
            channels: Array.from(parserState.channelsAtivos),
            totalMessages: parserState.totalMessages,
            wsDadosRecebidos,
            estadoRodada: CONFIG.estadoRodadaAtual || null
          });
        }
      } catch (e) {
        Logger.error('Falha em dependências secundárias (config/obs):', e?.message || e);
      }
    };

    // Rodamos a carga de config em paralelo com um timeout, mas NÃO bloqueamos o Overlay
    Promise.race([
      initProcess(),
      new Promise(resolve => setTimeout(resolve, 4000)) // Timeout de 4s para configs
    ]).finally(() => {
      Logger.info('Processo de inicialização de dependências concluído ou expirado.');
      
      // 3. Inicializar Overlay (Prioridade Máxima)
      if (typeof Overlay !== 'undefined' && !overlayInicializado) {
        try {
          Overlay.inicializar();
          overlayInicializado = true;
          CONFIG.overlayReady = true;
          
          if (Overlay.aplicarModoDebug) Overlay.aplicarModoDebug();
          Overlay.addLog('🧬 J.A.R.V.I.S. Ativo — Monitorando mesa', 'success');
          
          if (Array.isArray(CONFIG.strategyLibrary) && CONFIG.strategyLibrary.length > 0) {
            const ativas = CONFIG.strategyLibrary.filter((s) => s.active !== false).length;
            Overlay.addLog(`Estratégias: ${ativas} ativa(s)`, 'info');
          }
          
          sincronizarOverlayInicial();
        } catch (error) {
          console.error('[BetBoom Auto] Erro fatal ao renderizar Overlay:', error);
          Logger.error('Erro ao renderizar Overlay:', error?.message || error);
        }
      } else {
        Logger.warn('Overlay não encontrado ou já inicializado.');
      }
    });

    Logger.info('Fluxo de inicialização disparado.');
  }

  function inicializarSubframe() {
    Logger.info('Subframe em modo bridge-only.');
    console.log('[BetBoom Auto] [subframe] bridge-only ativo');
    // O subframe já escuta comandos via tratarMensagemWindow (registrado acima)
    // Expor BB_CLICK_CMD globalmente para teste via console
    window.BB_CLICK = async (alvo = 'player') => executarComandoClique(alvo);
    console.log('[BetBoom Auto] [subframe] BB_CLICK("player"/"banker"/"tie") disponível');
  }

  window.addEventListener('message', tratarMensagemWindow);
  document.addEventListener('click', tratarCliqueOperador, true);
  registrarListenersRuntime();
  injetarWebSocketInterceptor();

  if (IS_TOP_FRAME) {
    inicializarTopFrame().catch((error) => {
      Logger.error('Erro na inicialização do top frame:', error?.message || error);
      console.error('[BetBoom Auto] Erro na inicialização do top frame:', error);
    });

    // Expor função global para disparar clique no iframe da Evolution
    window.BB_CLICK = function (alvo = 'player', valor = null) {
      const iframes = Array.from(document.querySelectorAll('iframe'));
      const evoFrame = iframes.find(f =>
        f.src && (f.src.includes('evo-games.com') || f.src.includes('billing-boom.com'))
      );
      if (!evoFrame) {
        console.error('[BB_CLICK] ❌ Iframe da Evolution não encontrado.');
        if (overlayInicializado && typeof Overlay !== 'undefined' && Overlay.addLog) {
          Overlay.addLog('❌ Iframe Evolution não encontrado', 'error');
        }
        return;
      }
      console.log(`[BB_CLICK] Enviando comando para iframe: ${alvo} | valor: ${valor}`);
      evoFrame.contentWindow.postMessage({ source: 'bb-click-cmd', alvo, valor }, '*');
    };
    console.log('[BetBoom Auto] BB_CLICK("player"/"banker"/"tie") disponível no console');
  } else {
    inicializarSubframe();
  }
})();
