/**
 * BetBoom Event Store v1.0
 * =======================
 * Armazena histórico completo de eventos em IndexedDB.
 * Base para análise pós-factum e replay determinístico.
 *
 * Responsabilidades:
 * - Persistir eventos em IndexedDB
 * - Rotação automática (manter últimas 10k eventos)
 * - Indexação por roundId, timestamp, tipo
 * - API para query e export
 * - Suporte para replay
 */

const EventStore = (() => {
  const PREFIX = '[EventStore]';
  const DB_NAME = 'betboom-event-store';
  const DB_VERSION = 1;
  const STORE_NAME = 'events';
  const MAX_EVENTS = 10000;

  let db = null;
  let isInitialized = false;

  /**
   * Inicializar IndexedDB
   */
  function initDB() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) {
        console.warn(`${PREFIX} ⚠️ IndexedDB não disponível, usando fallback em memory`);
        resolve(null);
        return;
      }

      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => {
        console.error(`${PREFIX} ❌ Falha ao abrir IndexedDB:`, request.error);
        reject(request.error);
      };

      request.onsuccess = () => {
        db = request.result;
        isInitialized = true;
        console.log(`${PREFIX} ✅ IndexedDB inicializado`);
        resolve(db);
      };

      request.onupgradeneeded = (event) => {
        const database = event.target.result;
        if (!database.objectStoreNames.contains(STORE_NAME)) {
          const store = database.createObjectStore(STORE_NAME, { keyPath: 'id', autoIncrement: true });
          store.createIndex('roundId', 'roundId', { unique: false });
          store.createIndex('timestamp', 'timestamp', { unique: false });
          store.createIndex('eventType', 'eventType', { unique: false });
          console.log(`${PREFIX} 📋 Object Store criado com índices`);
        }
      };
    });
  }

  /**
   * Adicionar evento ao store
   */
  async function addEvent(eventType, data) {
    if (!db) {
      console.warn(`${PREFIX} ⚠️ IndexedDB indisponível, evento não persistido`);
      return { ok: false, motivo: 'db-unavailable' };
    }

    const event = {
      timestamp: Date.now(),
      eventType,
      data,
      roundId: data.roundId || null,
      traceId: data.traceId || `event-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`
    };

    return new Promise((resolve) => {
      try {
        const transaction = db.transaction([STORE_NAME], 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.add(event);

        request.onsuccess = () => {
          console.log(`${PREFIX} 📝 Evento armazenado: ${eventType}`);
          cleanupIfNeeded();
          resolve({ ok: true, id: request.result });
        };

        request.onerror = () => {
          console.error(`${PREFIX} ❌ Erro ao armazenar evento:`, request.error);
          resolve({ ok: false, erro: request.error.message });
        };
      } catch (e) {
        console.error(`${PREFIX} ❌ Exceção ao armazenar:`, e);
        resolve({ ok: false, erro: e.message });
      }
    });
  }

  /**
   * Limpar eventos antigos se ultrapassou MAX_EVENTS
   */
  async function cleanupIfNeeded() {
    if (!db) return;

    return new Promise((resolve) => {
      try {
        const transaction = db.transaction([STORE_NAME], 'readonly');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.count();

        request.onsuccess = () => {
          if (request.result > MAX_EVENTS) {
            console.log(`${PREFIX} 🧹 Limpando eventos (${request.result} > ${MAX_EVENTS})`);
            deleteOldestEvents(request.result - MAX_EVENTS);
          }
          resolve();
        };

        request.onerror = () => resolve();
      } catch (_) {
        resolve();
      }
    });
  }

  /**
   * Deletar N eventos mais antigos
   */
  async function deleteOldestEvents(count) {
    if (!db) return;

    return new Promise((resolve) => {
      try {
        const transaction = db.transaction([STORE_NAME], 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const index = store.index('timestamp');
        const range = IDBKeyRange.upperBound(Date.now() - 86400000); // 24h atrás
        index.openCursor(range).onsuccess = (event) => {
          const cursor = event.target.result;
          if (cursor && count > 0) {
            cursor.delete();
            count--;
            cursor.continue();
          }
        };

        transaction.oncomplete = () => {
          console.log(`${PREFIX} ✅ Limpeza concluída`);
          resolve();
        };
      } catch (_) {
        resolve();
      }
    });
  }

  /**
   * Query eventos por roundId
   */
  async function queryByRoundId(roundId) {
    if (!db) return [];

    return new Promise((resolve) => {
      try {
        const transaction = db.transaction([STORE_NAME], 'readonly');
        const store = transaction.objectStore(STORE_NAME);
        const index = store.index('roundId');
        const request = index.getAll(roundId);

        request.onsuccess = () => {
          resolve(request.result);
        };

        request.onerror = () => {
          console.error(`${PREFIX} ❌ Query failed:`, request.error);
          resolve([]);
        };
      } catch (e) {
        console.error(`${PREFIX} ❌ Exception:`, e);
        resolve([]);
      }
    });
  }

  /**
   * Query eventos por tipo
   */
  async function queryByEventType(eventType) {
    if (!db) return [];

    return new Promise((resolve) => {
      try {
        const transaction = db.transaction([STORE_NAME], 'readonly');
        const store = transaction.objectStore(STORE_NAME);
        const index = store.index('eventType');
        const request = index.getAll(eventType);

        request.onsuccess = () => {
          resolve(request.result);
        };

        request.onerror = () => {
          resolve([]);
        };
      } catch (_) {
        resolve([]);
      }
    });
  }

  /**
   * Exportar todos os eventos (para análise)
   */
  async function exportAll() {
    if (!db) return [];

    return new Promise((resolve) => {
      try {
        const transaction = db.transaction([STORE_NAME], 'readonly');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.getAll();

        request.onsuccess = () => {
          resolve(request.result);
        };

        request.onerror = () => {
          resolve([]);
        };
      } catch (_) {
        resolve([]);
      }
    });
  }

  /**
   * Obter estatísticas
   */
  async function getStats() {
    if (!db) return { available: false };

    return new Promise((resolve) => {
      try {
        const transaction = db.transaction([STORE_NAME], 'readonly');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.count();

        request.onsuccess = () => {
          resolve({
            available: true,
            totalEvents: request.result,
            dbName: DB_NAME,
            maxEvents: MAX_EVENTS
          });
        };

        request.onerror = () => {
          resolve({ available: false });
        };
      } catch (_) {
        resolve({ available: false });
      }
    });
  }

  /**
   * Limpar tudo (cuidado!)
   */
  async function clearAll() {
    if (!db) return;

    return new Promise((resolve) => {
      try {
        const transaction = db.transaction([STORE_NAME], 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.clear();

        request.onsuccess = () => {
          console.log(`${PREFIX} 🗑️ Todos os eventos foram removidos`);
          resolve();
        };

        request.onerror = () => {
          resolve();
        };
      } catch (_) {
        resolve();
      }
    });
  }

  // Public API
  return {
    init: initDB,
    addEvent,
    queryByRoundId,
    queryByEventType,
    exportAll,
    getStats,
    clearAll
  };
})();

// Auto-inicializar
if (typeof window !== 'undefined') {
  EventStore.init().then(() => {
    window.EventStore = EventStore;
    console.log('[EventStore] ✅ Módulo carregado e inicializado');
  }).catch((err) => {
    console.warn('[EventStore] ⚠️ Falha na inicialização:', err);
    window.EventStore = EventStore;
  });
}
