/**
 * HistoryIntegrity — Validador de integridade do histórico
 *
 * Responsabilidades:
 * 1. Separar realHistory (banca) vs renderedHistory (overlay)
 * 2. Comparar ordem, cores, quantidade
 * 3. Bloquear operações se match < 95%
 * 4. Emitir alertas catastóficos
 */

const HistoryIntegrity = (() => {
  let realHistory = [];          // Direto do Collector (fonte de verdade)
  let renderedHistory = [];      // O que está renderizado no overlay
  let perspectiveHistory = [];   // Análises/perspectivas (separadas)
  let lastValidationTime = 0;
  let isBlockingOperations = false;

  function normalizaCor(cor) {
    if (!cor) return null;
    const c = String(cor || '').toLowerCase();
    if (c.includes('azul') || c.includes('blue') || c.includes('black') || c.includes('pret')) return 'azul';
    if (c.includes('verm') || c.includes('red')) return 'vermelho';
    if (c.includes('emp') || c.includes('tie') || c.includes('white') || c.includes('green')) return 'empate';
    return null;
  }

  function compararSequencias(seq1, seq2) {
    if (!Array.isArray(seq1) || !Array.isArray(seq2)) return false;
    if (seq1.length !== seq2.length) return false;
    return seq1.every((item, idx) => normalizaCor(item.cor || item) === normalizaCor(seq2[idx].cor || seq2[idx]));
  }

  function validarIntegridade() {
    const agora = Date.now();
    if (agora - lastValidationTime < 500) {
      // Retornar último estado válido (não undefined)
      return {
        realCount: realHistory.length,
        renderedCount: renderedHistory.length,
        perspectiveCount: perspectiveHistory.length,
        matchRate: 100,
        missingRounds: [],
        duplicatedRounds: [],
        orderMismatch: false,
        divergencias: [],
        source: 'collector/overlay',
        status: 'OK',
        timestamp: agora,
        isBlockingOperations: false
      };
    }
    lastValidationTime = agora;

    const realCount = realHistory.length;
    const renderedCount = renderedHistory.length;
    const perspectiveCount = perspectiveHistory.length;

    let matchRate = 0;
    let divergencias = [];
    let missingRounds = [];
    let duplicatedRounds = [];
    let orderMismatch = false;

    // CORRIGIDO: Real=0 não é OK, é EMPTY
    if (realCount === 0) {
      matchRate = 100; // Vazio = válido tecnicamente
      isBlockingOperations = false; // Não bloqueia se vazio
    } else if (renderedCount === 0) {
      matchRate = 0;
      divergencias.push(`Rendered vazio enquanto Real tem ${realCount}`);
    } else if (renderedCount > realCount) {
      matchRate = 0;
      divergencias.push(`Rendered (${renderedCount}) > Real (${realCount}) — duplicatas ou erro de coleta`);
    } else {
      // Comparar últimos N itens do histórico real com o renderizado
      const compareSize = Math.min(realCount, renderedCount);
      const realTail = realHistory.slice(-compareSize);
      const renderedTail = renderedHistory.slice(-compareSize);

      if (compararSequencias(realTail, renderedTail)) {
        matchRate = 100;
      } else {
        // Contar erros
        let errors = 0;
        for (let i = 0; i < compareSize; i++) {
          const realCor = normalizaCor(realTail[i].cor || realTail[i]);
          const rendCor = normalizaCor(renderedTail[i].cor || renderedTail[i]);
          if (realCor !== rendCor) {
            errors++;
            if (i < 3) { // Registrar primeiras 3 divergências
              divergencias.push(`Rod ${i}: Real=${realCor} vs Rendered=${rendCor}`);
            }
          }
        }
        matchRate = Math.max(0, ((compareSize - errors) / compareSize) * 100);
      }

      // Detectar rounds faltando
      if (renderedCount < realCount) {
        const delta = realCount - renderedCount;
        missingRounds.push({ count: delta, lastRound: realHistory[realCount - 1]?.rodada });
      }

      // Detectar inversão de ordem
      if (renderedCount >= 2) {
        const last = renderedHistory[renderedCount - 1];
        const prev = renderedHistory[renderedCount - 2];
        if (last?.rodada && prev?.rodada && last.rodada < prev.rodada) {
          orderMismatch = true;
          divergencias.push(`Ordem invertida: Rod ${prev.rodada} > Rod ${last.rodada}`);
        }
      }
    }

    isBlockingOperations = matchRate < 95;

    // CORRIGIDO: Status deve ser EMPTY se realCount === 0
    let status = 'OK';
    if (realCount === 0) {
      status = 'EMPTY'; // Nenhum histórico carregado ainda
    } else if (matchRate >= 95) {
      status = 'OK';
    } else if (matchRate >= 70) {
      status = 'DEGRADED';
    } else {
      status = 'INVALID';
    }

    const integrity = {
      realCount,
      renderedCount,
      perspectiveCount,
      matchRate: Math.round(matchRate * 10) / 10,
      missingRounds,
      duplicatedRounds,
      orderMismatch,
      divergencias,
      source: 'collector/overlay',
      status,
      timestamp: agora,
      isBlockingOperations
    };

    // Log em [HistoryIntegrity]
    console.log(`[HistoryIntegrity] Real=${realCount} | Rendered=${renderedCount} | Perspective=${perspectiveCount} | Match=${integrity.matchRate}% | Status=${integrity.status}`);

    if (integrity.status !== 'OK') {
      console.warn(`[HistoryIntegrity] ⚠️ ${integrity.status}:`, integrity.divergencias);
    }

    return integrity;
  }

  function exibirAlertaCatastrofico(integrity) {
    // CORRIGIDO: Checar se integrity existe
    if (!integrity || !integrity.status) {
      return;
    }

    // Remover alerta se voltou para OK ou EMPTY
    if (integrity.status === 'OK' || integrity.status === 'EMPTY') {
      const existingAlert = document.getElementById('bb-history-alert-catastrophic');
      if (existingAlert) existingAlert.remove();
      return;
    }

    let existing = document.getElementById('bb-history-alert-catastrophic');
    if (existing) {
      existing.remove();
    }

    const alert = document.createElement('div');
    alert.id = 'bb-history-alert-catastrophic';
    alert.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: linear-gradient(135deg, #ef4444, #991b1b);
      color: white;
      padding: 20px 30px;
      border-radius: 12px;
      font-size: 14px;
      font-weight: bold;
      z-index: 99999;
      box-shadow: 0 0 30px rgba(239, 68, 68, 0.5);
      border: 2px solid #dc2626;
      text-align: center;
      max-width: 500px;
      word-wrap: break-word;
    `;

    const divContent = document.createElement('div');
    divContent.innerHTML = `
      <div style="margin-bottom: 12px; font-size: 24px;">🚨</div>
      <div style="margin-bottom: 12px; font-size: 16px;">HISTÓRICO INVÁLIDO</div>
      <div style="margin-bottom: 8px; font-size: 12px; color: rgba(255,255,255,0.8);">
        O overlay não confere com a banca.
      </div>
      <div style="margin-bottom: 12px; font-size: 11px; color: rgba(255,255,255,0.7);">
        Real: ${integrity.realCount} | Renderizado: ${integrity.renderedCount} | Match: ${integrity.matchRate}%
      </div>
      <div style="margin-bottom: 12px; background: rgba(0,0,0,0.3); padding: 8px; border-radius: 4px; font-size: 11px; max-height: 80px; overflow-y: auto;">
        ${integrity.divergencias.slice(0, 3).map(d => `<div>❌ ${d}</div>`).join('')}
      </div>
      <div style="font-size: 12px; font-weight: bold; margin-bottom: 12px;">
        ⛔ PREDIÇÃO, PADRÕES, F1 E CLIQUES BLOQUEADOS
      </div>
      <button id="bb-validate-history-btn" style="
        background: rgba(255,255,255,0.2);
        border: 1px solid white;
        color: white;
        padding: 8px 16px;
        border-radius: 6px;
        cursor: pointer;
        font-weight: bold;
        font-size: 12px;
      ">🔍 VALIDAR HISTÓRICO</button>
    `;

    alert.appendChild(divContent);
    document.body.appendChild(alert);

    // Botão de validação
    const btn = document.getElementById('bb-validate-history-btn');
    if (btn) {
      btn.addEventListener('click', () => {
        const newIntegrity = validarIntegridade();
        alert.remove();
        if (newIntegrity.status !== 'OK') {
          exibirAlertaCatastrofico(newIntegrity);
        }
      });
    }
  }

  return {
    /**
     * Atualiza o histórico real (fonte de verdade da banca)
     */
    atualizarRealHistory(novoHistorico) {
      if (Array.isArray(novoHistorico)) {
        realHistory = novoHistorico.map(r => ({
          cor: normalizaCor(r.cor || r),
          rodada: r.rodada || r.roundId || null,
          timestamp: r.timestamp || Date.now()
        }));
      }
    },

    /**
     * Atualiza o histórico renderizado (o que aparece na tela)
     */
    atualizarRenderedHistory(novoHistorico) {
      if (Array.isArray(novoHistorico)) {
        renderedHistory = novoHistorico.map(r => ({
          cor: normalizaCor(r.cor || r),
          rodada: r.rodada || r.roundId || null,
          timestamp: r.timestamp || Date.now()
        }));
      }
    },

    /**
     * Adiciona perspectiva (análise, predição) — NÃO é histórico real
     */
    atualizarPerspectiveHistory(perspectivas) {
      if (Array.isArray(perspectivas)) {
        perspectiveHistory = perspectivas;
      }
    },

    /**
     * Valida e retorna relatório de integridade
     */
    validar() {
      return validarIntegridade();
    },

    /**
     * Exibe alerta se história estiver inválida
     */
    atualizarAlerta() {
      const integrity = validarIntegridade();
      exibirAlertaCatastrofico(integrity);
      return integrity;
    },

    /**
     * Retorna se operações devem estar bloqueadas
     */
    deveBloquearOperacoes() {
      return isBlockingOperations;
    },

    /**
     * Retorna status da última validação
     */
    getStatus() {
      return {
        realCount: realHistory.length,
        renderedCount: renderedHistory.length,
        perspectiveCount: perspectiveHistory.length,
        isBlocking: isBlockingOperations,
        lastValidation: lastValidationTime
      };
    }
  };
})();
