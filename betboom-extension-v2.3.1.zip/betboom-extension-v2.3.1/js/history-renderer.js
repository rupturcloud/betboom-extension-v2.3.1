/**
 * HistoryRenderer — Renderização do histórico real
 *
 * Regra absoluta:
 * 1 rodada real = 1 bolinha
 * realHistory.length === renderedBalls
 *
 * Layout: CSS Grid 6 linhas × N colunas
 */

const HistoryRenderer = (() => {
  const ROWS = 6;
  const COLOR_MAP = {
    blue: { bg: '#1e3a8a', emoji: '🔵', name: 'Azul' },
    red: { bg: '#991b1b', emoji: '🔴', name: 'Vermelho' },
    green: { bg: '#166534', emoji: '🟢', name: 'Empate' }
  };

  let renderedBalls = [];

  /**
   * Normaliza cor para chave no COLOR_MAP
   */
  function normalizeColorForRender(color) {
    if (!color) return null;
    const c = String(color).toLowerCase().trim();

    if (c.includes('blue') || c.includes('azul') || c.includes('player') || c === 'p') {
      return 'blue';
    }
    if (c.includes('red') || c.includes('verm') || c.includes('banker') || c === 'b') {
      return 'red';
    }
    if (c.includes('green') || c.includes('empate') || c.includes('tie') || c === 't') {
      return 'green';
    }

    console.warn(`[HistoryRenderer] Cor desconhecida para render:`, color);
    return null;
  }

  /**
   * Renderiza uma bolinha individual
   */
  function renderBall(round, rowIndex, colIndex) {
    if (!round || !round.color) {
      console.warn(`[HistoryRenderer] Round inválido para renderizar:`, round);
      return null;
    }

    const normalizedColor = normalizeColorForRender(round.color);
    if (!normalizedColor) {
      console.warn(`[HistoryRenderer] Não conseguiu normalizar cor:`, round.color);
      return null;
    }

    const colorInfo = COLOR_MAP[normalizedColor];
    const ballId = `bb-ball_${colIndex}_${rowIndex}_${round.signature || round.roundId}`;

    const ballElement = document.createElement('div');
    ballElement.id = ballId;
    ballElement.className = `bb-bola bb-bola-${normalizedColor}`;
    ballElement.style.cssText = `
      grid-row: ${rowIndex + 1};
      grid-column: ${colIndex + 1};
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background-color: ${colorInfo.bg};
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      cursor: pointer;
      border: 2px solid rgba(255, 255, 255, 0.3);
      box-shadow: 0 0 8px rgba(0, 0, 0, 0.4);
      transition: transform 0.2s ease;
    `;
    ballElement.innerHTML = colorInfo.emoji;
    ballElement.title = `${colorInfo.name} — ${round.roundId || round.signature}`;

    // Adicionar hover effect
    ballElement.addEventListener('mouseenter', () => {
      ballElement.style.transform = 'scale(1.1)';
      ballElement.style.boxShadow = '0 0 16px rgba(255, 255, 255, 0.6)';
    });

    ballElement.addEventListener('mouseleave', () => {
      ballElement.style.transform = 'scale(1.0)';
      ballElement.style.boxShadow = '0 0 8px rgba(0, 0, 0, 0.4)';
    });

    return {
      element: ballElement,
      ballId,
      roundId: round.roundId,
      signature: round.signature,
      color: normalizedColor,
      rowIndex,
      colIndex,
      visible: true
    };
  }

  /**
   * Renderiza histórico real completo
   * REGRA: 1 rodada = 1 bolinha
   * VALIDAÇÃO: renderedBalls.length === realHistory.length
   */
  function renderRealHistory(container, realHistory) {
    if (!container) {
      console.error(`[HistoryRenderer] Container inválido`);
      return { success: false, reason: 'no_container', renderedBalls: 0 };
    }

    if (!Array.isArray(realHistory)) {
      console.error(`[HistoryRenderer] realHistory não é array:`, typeof realHistory);
      return { success: false, reason: 'not_array', renderedBalls: 0 };
    }

    const realCount = realHistory.length;

    if (realCount === 0) {
      console.log(`[HistoryRenderer] Histórico vazio — nada a renderizar`);
      // Limpar container
      container.innerHTML = '';
      renderedBalls = [];
      return { success: true, reason: 'empty_history', renderedBalls: 0 };
    }

    // Limpar container anterior
    container.innerHTML = '';
    renderedBalls = [];

    // Aplicar CSS Grid ao container
    container.style.cssText = `
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(40px, 1fr));
      grid-template-rows: repeat(${ROWS}, 40px);
      gap: 8px;
      padding: 12px;
      background-color: rgba(0, 0, 0, 0.3);
      border-radius: 8px;
      max-width: 100%;
      overflow: auto;
    `;

    // Renderizar cada rodada como 1 bolinha
    for (let i = 0; i < realCount; i++) {
      const round = realHistory[i];
      const rowIndex = i % ROWS;
      const colIndex = Math.floor(i / ROWS);

      const ballInfo = renderBall(round, rowIndex, colIndex);

      if (ballInfo && ballInfo.element) {
        container.appendChild(ballInfo.element);
        renderedBalls.push(ballInfo);
      } else {
        console.warn(`[HistoryRenderer] Falha ao renderizar bolinha ${i}:`, round);
      }
    }

    // VALIDAÇÃO OBRIGATÓRIA
    const validationLog = {
      realRounds: realCount,
      tabuleiroColunas: realCount,
      renderedBalls: renderedBalls.length,
      mode: 'REAL_HISTORY_ONLY',
      gridRows: ROWS,
      gridCols: Math.ceil(realCount / ROWS)
    };

    const isValid = renderedBalls.length === realCount;

    console.log(`[HistoryRenderDebug]`, validationLog);

    if (!isValid) {
      console.error(`🚨 HISTÓRICO REAL INVÁLIDO:`, {
        realRounds: realCount,
        renderedBalls: renderedBalls.length,
        mismatch: realCount - renderedBalls.length
      });

      // Mostrar alerta visual
      const alertEl = document.createElement('div');
      alertEl.style.cssText = `
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: linear-gradient(135deg, #ef4444, #991b1b);
        color: white;
        padding: 20px;
        border-radius: 8px;
        z-index: 99999;
        font-weight: bold;
        text-align: center;
      `;
      alertEl.innerHTML = `🚨 HISTÓRICO REAL INVÁLIDO<br/>renderedBalls(${renderedBalls.length}) != tabuleiroColunas(${realCount})`;
      document.body.appendChild(alertEl);

      setTimeout(() => alertEl.remove(), 5000);

      return {
        success: false,
        reason: 'render_mismatch',
        renderedBalls: renderedBalls.length,
        expected: realCount
      };
    }

    console.log(`[HistoryRenderer] ✓ Histórico renderizado com sucesso:`, {
      rounds: realCount,
      balls: renderedBalls.length,
      rows: ROWS,
      cols: Math.ceil(realCount / ROWS)
    });

    return {
      success: true,
      reason: 'rendered_ok',
      renderedBalls: renderedBalls.length,
      expected: realCount
    };
  }

  /**
   * Retorna histórico renderizado (para comparação)
   */
  function getRenderedHistory() {
    return renderedBalls.map(ball => ({
      ballId: ball.ballId,
      roundId: ball.roundId,
      signature: ball.signature,
      color: ball.color,
      rowIndex: ball.rowIndex,
      colIndex: ball.colIndex,
      visible: ball.visible,
      element: null // Não expor elemento DOM
    }));
  }

  /**
   * Atualiza visibilidade de uma bolinha
   */
  function setBallVisibility(ballId, visible) {
    const ball = renderedBalls.find(b => b.ballId === ballId);
    if (ball) {
      ball.visible = visible;
      if (ball.element) {
        ball.element.style.opacity = visible ? '1' : '0.3';
      }
      return true;
    }
    return false;
  }

  /**
   * Retorna count de bolinhas renderizadas
   */
  function getRenderedBallCount() {
    return renderedBalls.length;
  }

  /**
   * Valida integridade renderizada
   */
  function validateRendered(realHistoryCount) {
    const renderedCount = renderedBalls.length;
    const isValid = renderedCount === realHistoryCount;

    return {
      realCount: realHistoryCount,
      renderedCount,
      isValid,
      status: isValid ? 'VALID' : 'INVALID',
      mismatch: realHistoryCount - renderedCount
    };
  }

  /**
   * Limpa renderização
   */
  function clearRendered() {
    renderedBalls = [];
  }

  return {
    renderRealHistory,
    renderBall,
    getRenderedHistory,
    setBallVisibility,
    getRenderedBallCount,
    validateRendered,
    clearRendered,
    ROWS,
    COLOR_MAP
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = HistoryRenderer;
}
